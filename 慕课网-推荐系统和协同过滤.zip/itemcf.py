# -*- coding: utf-8 -*-
"""item cf main"""
"""先写主体流程:再细化每个分功能函数"""
import sys
import math
import operator
#导入某个文件夹下的源码文件可以这么写代码
sys.path.append('C:/Users/Administrator/recommend/')
import reader 

def base_contribute_score():
    #item cd base sim contribution score.
    return 1
def update_one_contribute_score(user_total_click_num):
    #升级上述函数:item cf update sim contribution score by one user,用户点击越少对总体的贡献率要高些，点击过多的贡献率要少些
    return 1/math.log10(1+user_total_click_num)
def update_two_contribute_score(click_time_one,click_time_two):
    delta_time=abs(click_time_one-click_time_two)
    total_sec=60*60*24
    delta_time=delta_time/total_sec #让它变成一个天的概念:点击相差一天和两天贡献率是差不多的
    return 1/(1+delta_time)
#def cal_item_sim(user_click):
#    """
#    Args:
#        user_click:dict,key:userid;value:[itemid1,itemid2,...]
#    Return:
#        dict,key:itemid_i,value:dict{key1=itemid_i,value1=:simscore}
#    """
#    co_appear={}
#    item_user_click_time={}
#    for user,itemlist in user_click.items():
#        #在某个用户的点击序列里面,任何两个item都会被该用户所共现
#        for index_i in range(0,len(itemlist)):
#            itemid_i=itemlist[index_i]
#            item_user_click_time.setdefault(itemid_i,0) 
#            #因为字典比较多,判断itemid存不存在呢直接用setdefault(),不存在的key可以直接设定初值
#            item_user_click_time[itemid_i]+=1
#            #在计算用户相似度的时候,分母还得分别除一下(该item被多少个用户点击过)
#            for index_j in range(index_i+1,len(itemlist)):
#                itemid_j=itemlist[index_j]
#                #item_i&item_j对user的共现
#                co_appear.setdefault(itemid_i,{})
#                co_appear[itemid_i].setdefault(itemid_j,0)
#                #第一版时的base_contribute_score函数
#                #co_appear[itemid_i][itemid_j]=+base_contribute_score()
#                #co_appear[itemid_i][itemid_j]=+update_one_contribute_score(len(itemlist)) #用户的总点击次数
                 ##item_j&item_i对user的共现
#                co_appear.setdefault(itemid_j,{})
#                co_appear[itemid_j].setdefault(itemid_i,0)
#                #co_appear[itemid_j][itemid_i]=+base_contribute_score()
                 #co_appear[itemid_i][itemid_j]=+update_one_contribute_score(len(itemlist)) 
#    item_sim_score={}
#    item_sim_score_sorted={}
#    for itemid_i,relate_item in co_appear.items():
#        for itemid_j,co_time in relate_item.items():
#            #sim_score=co_time/math.sqrt(item_user_click_time[itemid_i],item_user_click_time[itemid_j]) #改进整除//乘法*,引入div
#            #只能使用写出算出商值
#            sim_score=co_time/math.sqrt(item_user_click_time[itemid_i]*item_user_click_time[itemid_j])
#            item_sim_score.setdefault(itemid_i,{})
#            item_sim_score[itemid_i].setdefault(itemid_j,0)
#            item_sim_score[itemid_i][itemid_j]=sim_score
#    #对字典做排序
#    for itemid in item_sim_score:
#        #sorted()返回的是list=[(),(),...],元组的第一个位置为key,下一位置为value
#        item_sim_score_sorted[itemid]=sorted(item_sim_score[itemid].items(),key=operator.itemgetter(1),reverse=True)
#    return item_sim_score_sorted 
def cal_item_sim(user_click,user_click_time):
    """
    Args:
        user_click:dict,key:userid;value:[itemid1,itemid2,...]
        user_click_time:引入的目的(物理意义)是依托于同一个用户对不同item的点击时间的差,如果这个差越小对点击的相似性的共现会越大
    Return:
        dict,key:itemid_i,value:dict{key1=itemid_i,value1=:simscore}
    """
    co_appear={}
    item_user_click_time={}
    for user,itemlist in user_click.items():
        #在某个用户的点击序列里面,任何两个item都会被该用户所共现
        for index_i in range(0,len(itemlist)):
            itemid_i=itemlist[index_i]
            item_user_click_time.setdefault(itemid_i,0) 
            #因为字典比较多,判断itemid存不存在呢直接用setdefault(),不存在的key可以直接设定初值
            item_user_click_time[itemid_i]+=1
            #在计算用户相似度的时候,分母还得分别除一下(该item被多少个用户点击过)
            for index_j in range(index_i+1,len(itemlist)):
                itemid_j=itemlist[index_j]
                if user+'_'+itemid_i not in user_click_time:
                    click_time_one=0
                else:
                    click_time_one=user_click_time[user+'_'+itemid_i]
                if user+'_'+itemid_j not in user_click_time:
                    click_time_two=0
                else:
                    click_time_two=user_click_time[user+'_'+itemid_j]
                #item_i&item_j对user的共现
                co_appear.setdefault(itemid_i,{})
                co_appear[itemid_i].setdefault(itemid_j,0)
                co_appear[itemid_i][itemid_j]=+update_two_contribute_score(click_time_one,click_time_two)
                #item_j&item_i对user的共现
                co_appear.setdefault(itemid_j,{})
                co_appear[itemid_j].setdefault(itemid_i,0)
                co_appear[itemid_j][itemid_i]=+update_two_contribute_score(click_time_one,click_time_two)
    item_sim_score={}
    item_sim_score_sorted={}
    for itemid_i,relate_item in co_appear.items():
        for itemid_j,co_time in relate_item.items():
            #sim_score=co_time/math.sqrt(item_user_click_time[itemid_i],item_user_click_time[itemid_j]) #改进整除//乘法*,引入div
            #只能使用写出算出商值
            sim_score=co_time/math.sqrt(item_user_click_time[itemid_i]*item_user_click_time[itemid_j])
            item_sim_score.setdefault(itemid_i,{})
            item_sim_score[itemid_i].setdefault(itemid_j,0)
            item_sim_score[itemid_i][itemid_j]=sim_score
    #对字典做排序
    for itemid in item_sim_score:
        #sorted()返回的是list=[(),(),...],元组的第一个位置为key,下一位置为value
        item_sim_score_sorted[itemid]=sorted(item_sim_score[itemid].items(),key=operator.itemgetter(1),reverse=True)
    return item_sim_score_sorted 

        
           
def cal_recom_result(sim_info,user_click):    
    """
    recomend by itemcf
    Args:
        sim_info:item sim dict
        user_click:user click dict
    Return:
        dict,key:userid,value=dict{key1:itemid,value1:recomend_score}
    """
    recent_click_num=3
    topk=5
    recomend_info={}
    for user in user_click:
        click_list=user_click[user] #用户对因的点击商品列表
        recomend_info.setdefault(user,{})
        for itemid in click_list[:recent_click_num]:
            if itemid not in sim_info:
                continue
            #发现每一个item还要重新排序会极耗时间,所以在上一个结果中先做排序再返回item_sim_score
            #只取每个item最相似的部分来做推荐
            for itemsimzuhe in sim_info[itemid][:topk]:
                #上一个函数中使用了sorted()排序后字典变为list=[(),(),...]
                itemsimid=itemsimzuhe[0]
                itemsiscore=itemsimzuhe[1]
                recomend_info[user][itemsimid]=itemsiscore
    return recomend_info    
            
def debug_itemsim(item_info,sim_info):
    """
    show itemsim info
    Args:
        item_info:dict,key:itemid,value:[title,category]
        sim_info:dict,key1:itemid,value1=[(itemid1,simscore1),(),...]
    """  
    fixed_itemid='1172'
    if fixed_itemid not in item_info:
        print('invalid itemid...')
        return
    [title_fix,category_fix]=item_info[fixed_itemid]
    #for zuhe in sim_info[fixed_itemid]:
    #相似的电影太多选择只取出最相似的5个电影
    for zuhe in sim_info[fixed_itemid][:5]:
        itemid_sim=zuhe[0]
        sim_score=zuhe[1]
        if itemid_sim not in item_info:
            continue
        [title,category]=item_info[itemid_sim]
        print(title_fix+'\t'+category_fix+'\tsim:'+title+'\t'+category+'\t'+str(sim_score))
        
def debug_recomentresult(recomend_result,item_info):
    """"
    debug recomentresult
    Args:
        rcomend_result,key:userid,value=dict{key1:itemid,value1:recomend_score}
        item_info:dict,key=itemid,value:[title,category]
    Return:
        给某个用户推荐的结果已经产出了
    """        
    user_id='1'
    if user_id not in recomend_result:
        print('invalid userid...')
        return
    for zuhe in sorted(recomend_result[user_id].items(),key=operator.itemgetter(1),reverse=True):
        itemid,score=zuhe
        if itemid not in item_info:
            continue   
        print(",".join(item_info[itemid])+'\t'+str(score))
  
    


def main_flow():
    """main flow of itemcf"""
    user_click,user_click_time=reader.get_user_click('ratings.txt')
    item_info=reader.get_item_info('movies.txt')
    sim_info=cal_item_sim(user_click,user_click_time)
    #debug物品间的相似度
    debug_itemsim(item_info,sim_info)
    ##recomend_result=cal_recom_result(sim_info,user_click)
    #print(recomend_result['6'])
    #dubug 用户间的相似度
    ##debug_recomentresult(recomend_result,item_info)
    
    
if __name__=='__main__':
    main_flow()
    #item_sim_score={'1':[4,5,1,2,7,3,92,32]}
    #zhou=sorted(item_sim_score['1'],reverse=True) #字典value=list时的排序这么来用
    
    
    
    
    
    
    
    
    
    
    
    
    
    