# -*- coding: utf-8 -*-
"""
user cf main algo:
    1.首先计算user相似度矩阵;
    2.根据user相似度矩阵给用户推荐item物品;
"""
import sys
import math
import operator
#导入某个文件夹下的源码文件可以这么写代码
sys.path.append('C:/Users/Administrator/recommend/')
import reader 
def transfer_user_click(user_click):
    """get item by user_click
       Args:
           user_click=dict{key:userid,value=[itemid1,itemid2,....]}
       Return:
           dict,key:itemid;value:[userid1,userid2,...]
    """
    item_click_by_user={}
    for user in user_click:
        item_list=user_click[user] #按用户取出用户对应的点击序列
        for itemid in item_list:
            item_click_by_user.setdefault(itemid,[])
            item_click_by_user[itemid].append(user) #倒排的使用
    return item_click_by_user

def update_contribute_score(item_user_click_count):
    """busercf user contribution score update version1:
        惩罚那些被很多人点击过的item对于相似矩阵的贡献程度
    Args:
        item_user_click:how many users have clicked this item
    return:
        contribution score.
    """
    return 1/math.log10(1+item_user_click_count)

def cal_user_sim(item_click_by_user):
    #完成计算用户相似度的函数的定义
    """
    Agrs:
        input:item_click_by_user,dict={key:itemid,value=[userid1,userid2,...]}
    Return:
        dict,key:itemid,value:simscore
    """
    #点击贡献率的公式
    co_appear={} #分子:共现
    user_click_count={} #每个用户分别点击了多少个item
    #对于出现在同一个item点击的user序列中的两个user,他们的共现都会+1
    for itemid,user_list in item_click_by_user.items(): #获得字典每一项的键值对
        for index_i in range(0,len(user_list)):
            user_i=user_list[index_i]
            user_click_count.setdefault(user_i,0)
            user_click_count[user_i]+=1
            for index_j in range(index_i+1,len(user_list)):
                user_j=user_list[index_j]
                co_appear.setdefault(user_i,{})
                co_appear[user_i].setdefault(user_j,0)
                co_appear[user_i][user_j]+=update_contribute_score(len(user_list))#传入是他被[多少个用户=user_list长度]点击过
                co_appear.setdefault(user_j,{})
                co_appear[user_j].setdefault(user_i,0)
                co_appear[user_j][user_i]+=update_contribute_score(len(user_list))
    user_sim_info={}
    for user_i,relate_user in co_appear.items():
        user_sim_info.setdefault(user_i,{})
        for user_j,cotime in relate_user.items():
            user_sim_info[user_i].setdefault(user_j,0)
            user_sim_info[user_i][user_j]=cotime/math.sqrt(user_click_count[user_i]*user_click_count[user_j])
    #给user_sim_info 排序
    user_sim_info_sorted={}
    for user in user_sim_info:
        #sorted()排序完毕是[(userid1,score1),(),...]
        user_sim_info_sorted[user]=sorted(user_sim_info[user].items(),key=operator.itemgetter(1),reverse=True)
    return user_sim_info_sorted
                

def cal_recom_result(user_click,user_sim):
    """
    recomend by userid algo
    Args:
        user_click:dict,key:userid,value:[itemid1,itemid2,...]
        user_sim:dict,key:userid,value:[(useridj,score1),(useridk,score2),...]
    Return:
        dict,key:userid,value=dict{key:itemid,value:recomend_score}
    """
    recomend_result={}
    topk_user=3
    item_num=5
    #我们是根据用户的相似用户所行为过的item来完成推荐的
    #这里如果相似用户行为过的物品,该用户行为过需要过滤掉.
    for user,item_list in user_click.items():
        tmp_dict={} #完成过滤
        for itemid in item_list:
            tmp_dict.setdefault(itemid,1) #item在list中就置1
        recomend_result.setdefault(user,{})
        #取得该用户的相似用户,取出最相似的topk_user=3个
        for zuhe in user_sim[user][:topk_user]:
            userid_j,sim_score=zuhe #组合的构成是用户、相似用户分
            #userid_j没有点击序列就过滤掉
            if userid_j not in user_click:
                continue
            #如果有,则根据他行为过的item(这里用5个)来做推荐
            for itemid_j in user_click[userid_j][:item_num]:
                recomend_result[user].setdefault(itemid_j,sim_score)
    return recomend_result

def debug_user_sim(user_sim):
    """
    print user sim result
    Args:
        user_sim,dict,key:userid;value:[(userid1,score1),(userid2,score2)]
    """
    topk=5
    fix_user="1"
    if fix_user not in user_sim:
        print("invalid user...")
        return 
    for zuhe in user_sim[fix_user][:topk]:
        userid,score=zuhe
        print(fix_user+'\tsim_user: '+userid+'\t'+ str(score))

def debug_recomend_result(item_info,recomend_result):
    """
    print recomend result for user
    Args:
        item_info:key:itemid,value:[title,category]
        recomend_result:key:userid,value={key:itemid,value:recomend_score}
    """
    fix_user="1"
    if fix_user not in recomend_result:
        print("invalid user for recomend result...")
        return 
    for itemid in recomend_result['1']:
        if itemid not in item_info:
            continue
        recomend_score=recomend_result['1'][itemid]
        print('recomend_result: '+','.join(item_info[itemid])+'\t'+str(recomend_score))
 
    
def main_flow():
    """main flow"""
    user_click,user_click_time=reader.get_user_click('ratings.txt')
    item_info=reader.get_item_info('movies.txt')
    item_click_by_user=transfer_user_click(user_click)
    user_sim=cal_user_sim(item_click_by_user)
    #1.debug相似的用户
    debug_user_sim(user_sim)
    print('---------------------分割线--------------------')
    recomend_result=cal_recom_result(user_click,user_sim)
    #print(recomend_result['1'])
    #2.debug推荐结果
    debug_recomend_result(item_info,recomend_result)
    
    
if __name__=='__main__':
    main_flow()
    
    
    
    

