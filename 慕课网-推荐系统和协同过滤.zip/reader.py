# -*- coding: utf-8 -*-
import os
#def get_user_click(rating_file):
#    """
#    get user click list
#    args:
#        rating_file:input file
#    return:
#        dict, key:userid;value:[item1,item2,...]
#    """
#    if not os.path.exists(rating_file):
#        print('======')
#        return {}
#    fp=open(rating_file)
#    num=0
#    user_click={}
#    for line in fp:
#        if num==0:
#            num+=1
#            continue
#        #按行分割
#        item=line.strip().split(',')
#        if len(item)<4:
#            continue
#        [userid,itemid,rating,timestamp]=item
#        #选出用户评分大于3分的电影itemid则认为用户喜欢item
#        if float(rating)<3.0:
#            continue
#        if userid not in user_click:
#            user_click[userid]=[]
#        user_click[userid].append(itemid)
#    fp.close()
#    #返回数据结构
#    return user_click
def get_user_click(rating_file):
    """
    get user click list
    args:
        rating_file:input file
    return:
        dict, key:userid;value:[item1,item2,...]
    """
    if not os.path.exists(rating_file):
        print('======')
        #========begin========
        return {},{}
        #========end========
    fp=open(rating_file)
    num=0
    user_click={}
    #========begin========
    user_click_time={} 
    #========end========
    for line in fp:
        if num==0:
            num+=1
            continue
        #按行分割
        item=line.strip().split(',')
        if len(item)<4:
            continue
        [userid,itemid,rating,timestamp]=item
        #========begin========
        if userid+'_'+itemid not in user_click_time:
            user_click_time[userid+'_'+itemid]=int(timestamp)
        #========end========
        #选出用户评分大于3分的电影itemid则认为用户喜欢item
        if float(rating)<3.0:
            continue
        if userid not in user_click:
            user_click[userid]=[]
        user_click[userid].append(itemid)
    fp.close()
    #返回数据结构
    #========begin========
    return user_click,user_click_time
    #========end========
def get_item_info(item_file):
    """
    get item info(title,category)
    Args:
        item_file:input iteminfo file
    return:
        a dict,key:itemid;value=[title,category]
    """
    if not os.path.exists(item_file):
        return {}
    fp=open(item_file)
    num=0
    item_info={}
    for line in fp:
        if num==0:
            num+=1
            continue
        #按行分割
        item=line.strip().split(',')
        #过滤小于3的列
        if len(item)<3:
            continue
        if len(item)==3:
            [itemid,title,category]=item
        elif len(item)>3:
            itemid=item[0]
            category=item[-1]
            #大于3,title是后面所有的拼接
            title=",".join(item[1:-1])
        #选出用户评分大于3分的电影itemid
        if itemid not in item_info:
            item_info[itemid]=[title,category]
    fp.close()
    #返回数据结构
    return item_info
    
#测试一下功能
'''
if __name__=='__main__':
    """"测试第一个函数"""
    user_click=get_user_click('C:/Users/Administrator/recommend/ratings.txt')
    print(user_click)
    print(user_click['1']) #查看第一个用户喜欢的item数据
#    #获得所有用户的itemid的唯一索引方便造数据
#    totallist=[]
#    for i in range(1,len(user_click)):
#        for j in range(len(user_click[str(i)])):
#            totallist.append(user_click[str(i)][j])
#        #user_click['1']
#        #totallist.append(user_click[str(i)]) 
#    import numpy as np
#    #totallist1=np.array(totallist).reshape(1,-1)
#    value_unique=list(set(totallist))
#    value_unique=sorted(value_unique)
    """测试第二个函数"""
    item_info=get_item_info('C:/Users/Administrator/recommend/movies.txt')
    print(item_info)
    print(item_info['17'])
    print(item_info['52'])
'''     















